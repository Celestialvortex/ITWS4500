Lab 1, here we go!

School hosted working source: https://afsws.rpi.edu/AFS/home/02/franse/webdev/lab1/lab1/tweet_ticker.html

Tried to have a clean, full screen ticker, added a few of the details from the .json that seemed relevant. Couldnt get the alt image function to work, but that would definitely be a goal for the future. 

Also seems to sometimes have problems after the first few cycles with transistions, and im not sure why. 

Had to use w3schools and the bootstrap guide for help with animations. Still struggling with them, but im going to work more with them for next lab anyway, so hopefully that skillset improves. 

NOt sure if we need anything else in this writeup.

-Elisa