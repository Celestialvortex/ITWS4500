'use strict';

// Load dependencies
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const server = require('http').createServer(app);
const path = require('path');
const fs = require('fs');
const https = require('https');
const request = require('request');
const consumerKey = 'XcFqGQvlAmCSR6GtdsP7B941A';
const consumerSecret = 'iUibsPEuZI0mtn4I89qOGjmPVP12E18ypIEY58mApEG9EArSKI'; //stuff given by twitter to let you use their stuff
const outputFilename = 'franse-tweets'; //as requested by the lab
const csvjson = require('csvjson');
const jsonxml = require('jsontoxml');
const mongoose = require('mongoose');
const dbName = 'lab8';
const db = mongoose.connect('mongodb://localhost/' + dbName);
var items;
var csv;
var jsonnnn;
var type = 1;
var tweets = [];
var csvOptions = {
    delimiter: ',',
    wrap: false
  };

//set up mongodb/mongoose stuff
//can i say that the person who decided to call it mongoose was very clever?
//because they definitely were
var tweetSchema = new mongoose.Schema({}, { strict: false });
var Tweet = mongoose.model('Tweet', tweetSchema);
app.use(express.static(__dirname));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
//when gettweets is posted

//to get the tweets
app.post('/getTweets', (req, res) => {
  var query = req.body.query;
  var numberr = req.body.numberr;

  authorizeApp(query, numberr, getTweets).then(fulfilledVal => {
    res.json({
      message: loadMessage(query)
    });
  }, rejectedVal => {
  });
});
//to clear collected tweets
app.get('/clearTweets', (req, res) => {
  Tweet.remove().exec();
});
//to show the tweets
app.post('/displayTweets', (req, res, csvOptions) => {
  var format = Object.getOwnPropertyNames(req.body)[0];
  var writeData = typesetter(format, csvOptions);
  var query = Tweet.find();
  query.exec((err, docs) => {
    res.json({
      'docs': docs,
      'formatted': writeData
    });
  });
});

//take the info and put it in the right format
function typesetter(format, csvOptions) {

    if (format == 'JSON'){
      return JSON.stringify(tweets, null, 2);}
    if (format =='XML'){
      return jsonxml(tweets);}
    if (format == 'CSV'){
      return csvjson.toCSV(tweets, csvOptions);}
      ;

  }

//to put the tweets in the file
app.post('/exportTweets', (req, res, csvOptions) => {
  var format = Object.getOwnPropertyNames(req.body)[0];
  var writeData = typesetter(format, csvOptions);
  var newOutputFilename = outputFilename + '.' + format;
  fs.writeFile(newOutputFilename, writeData);
  res.send('Wrote Tweets to File!');
});

//say you found stuff
function loadMessage(query) {
  return 'Found  tweet(s) related to "' + query + '".'
}
//based on old guide
function authorizeApp(query, numberr, callback) {
  var accessToken = '';

  // Get application OAuth bearer token
  var bearerTokenCredentials = consumerKey + ':' + consumerSecret;
  var encodedCredentials = new Buffer(bearerTokenCredentials).toString('base64');
  var authRquestOptions = {
    hostname: 'api.twitter.com',
    path: '/oauth2/token',
    method: 'POST',
    headers: {
      'Authorization': 'Basic ' + encodedCredentials,
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    }
  };
//more auth
  var authRequest = https.request(authRquestOptions, (res) => {
    res.setEncoding('utf8');
    res.on('data', (chunk) => {
      accessToken = JSON.parse(chunk).access_token;
      callback(accessToken, query, numberr);
    });


  });

  var mainbit = 'grant_type=client_credentials';
  authRequest.write(mainbit);
  authRequest.end();
  return new Promise((resolve, reject) => {
    resolve(tweets);
  });
}
//get your tweets(formerly tweetgrabber)
function getTweets(accessToken, query, numberr) {
  var tweetSearchOptions = { 
    count: numberr //obeys numbers set 
  };
  if (query) {
    tweetSearchOptions.q = query; //search via the query given
  }


  request.get({
    headers: { 'Authorization': 'Bearer ' + accessToken },
    url: 'https://api.twitter.com/1.1/search/tweets.json',
    json: true,
    qs: tweetSearchOptions
  }, (e, r, b) => {
    tweets = b.statuses;
    Tweet.remove().exec();
    Tweet.insertMany(tweets);
  });
}

server.listen(3000, () => {
  Tweet.remove().exec();
	console.log('lab8 server listening on port 3000');
});
