'use strict';

// Load dependencies
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const server = require('http').createServer(app);
const path = require('path');
const fs = require('fs');
const https = require('https');
const request = require('request');
const consumerKey = 'XcFqGQvlAmCSR6GtdsP7B941A';
const consumerSecret = 'iUibsPEuZI0mtn4I89qOGjmPVP12E18ypIEY58mApEG9EArSKI'; //stuff given by twitter to let you use their stuff
const outputFilename = 'franse-tweets'; //as requested by the lab
var items;
let csv;
var jsonnnn;
var type = 1;

// Set root folder
app.use(express.static(__dirname)); //use express
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true })); //deal with encoded and non encoded json

app.post('/Tweetgrabber', (req, res) => {
  var query = req.body.query; //pull query from html page
  var numberr = req.body.numberr; //number pulled from html page
  authorizeApp(query, numberr, res, req);//authroize with twitter
  if (query != ''){ //if something is in the text box, do the thing
  res.send('You have now saved '+numberr+' tweets in regards to '+query+'!');    //confirm to users}
}

    else{//give error and stop the thing
      res.send('uh oh! you have an error! Please refresh and try again!');
      return;
    }
});

function Tweetgrabber(accessToken, query, numberr, req, res) { //function for grabbing tweets
  var tweetSearchOptions = { 
    count: numberr //obeys numbers set 
  };

  if (query) {
    tweetSearchOptions.q = query; //search via the query
  }

fs.stat('franse-tweets.json', function(err, stat, res, req) {
    if(err == null) {
        //this is where i would have transfered to the other page (confirm.html) If the function was successful, i would have set the err.code to ENOENT so it was passed as if the file did not exist,
        //and then run it normally.

    } if(err.code == 'ENOENT') {
        // file does not exist
    request.get({
    headers: { 'Authorization': 'Bearer ' + accessToken }, // get data using tokens
    url: 'https://api.twitter.com/1.1/search/tweets.json',
    json: true,
    qs: tweetSearchOptions
  }, (e, r, b) => {
    jsonnnn = b;
    fs.writeFile(outputFilename, JSON.stringify(b.statuses, null, 2), (err) => { //attempt to write the file
      if (err) {
        throw err;
      }


    });


  });


items = jsonnnn.statuses;
const replacer = (key, value) => value === null ? '' : value // specify how you want to handle null values here
const header = Object.keys(items[0])
csv = items.map(row => header.map(fieldName => JSON.stringify(row[fieldName], replacer)).join(','))
csv.unshift(header.join(','))
csv = csv.join('\r\n')
if (type == 2){
  fs.writeFile(outputFilename,csv, (err) => {
    if (err) {
      throw err;
    }
  });
}


    } else {
        console.log('Some other error: ', err.code);
    }
});



}

function typesetter(numnum){ //judges whether or not to replace it with csv
 if (numnum == 1){ 
  type = 1;
  outputFilename = 'franse-tweets.json';
 }
 else{
  type = 2;
  outputFilename = 'franse-tweets.csv';
 }
}
  // as instructed by online twitter API guide
}

function authorizeApp(query, numberr, res, req) { // used to authorize probing of twitter. Consent is a good thing! 

  var bearerTokenCredentials = consumerKey + ':' + consumerSecret; //my info
  var encodedCredentials = new Buffer(bearerTokenCredentials).toString('base64');
  var authRquestOptions = { //options in regards to request
    hostname: 'api.twitter.com',
    path: '/oauth2/token',
    method: 'POST',
    headers: {
      'Authorization': 'Basic ' + encodedCredentials,
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    }
  };

  var authRequest = https.request(authRquestOptions, (res) => { //once authorized, get data and encode to where parseable, 
    res.setEncoding('utf8'); 
    res.on('data', (chunk) => {
      var accessToken = JSON.parse(chunk).access_token; //parse of json
      Tweetgrabber(accessToken, query, numberr); // run above function
    });
  });

  var body = 'grant_type=client_credentials';
  authRequest.write(body);
  authRequest.end();
  console.log('all done with request for '+query);
}

server.listen(3000);
