Alright, R took a lot more massaging than expected, and thank god for issac helping me smooth out all the wrinkles

FOr this project, I took in data from a pet friendship site called petster, as explored through the stats website Konect
http://konect.uni-koblenz.de/networks/petster-carnivore

By using two SCV files with metadata and connection data, I plotted the relationship network people created for their pets online.



What dataset did you use and why? 

Given we are going to be doing a twitter scraper soon, I really wanted to explore R in a way that wouldnt be a duplicate of my work. Therefore, I looked at other sites to find good datasets, but this one seemed the most put together in a semi interesting topic



What did you learn about the dataset from your exploration?

That using old data for pet sites is incredibly disheartening when half of your values have names like "RIP SMOKEY WE LOVE YOU" and "SNUGGLES REST IN PEACE 2015"
I also learned R studio loves to crash when given huge sets of data, and without saving frequently you can lose huge swaths of work

In all seriousness, I learned that most friend groups were centered around singular individuals, with many pets being given a connection to a singlular member of the group, and few having as many connections dispersed within the group. This member was also often sourced back to larger groups

Groups with small amounts of very connnected individuals were also common, but these often didnt have as great of connections back to the largest networks





What challenges did you face (due to R, the dataset, or formating), and how did you overcome them?

Oh boy

Not only did I have to navigate the problems with using two CSV's, and that they didnt want to fit well into native data structures, but there was all sorts of problems with them/r I didnt expect. 
I didnt expect for IF statements to be able to return multiple values (fixed with adding any())
I didnt expect for what I thought was clean data to have all sorts of modifiers added to the names that broke entire rows out of the dataset (i'm looking at you, \\__--VoDkA--__//)
			FOr that one, I had to run through the CSV's with a replace function to get rid of extra spaces and punctuation that might indicate an exit in R
I didn't expect for the pet ids to not correlate directly with the edge csv: sometimes accounts had been deleted and data simply did not exist to create a direct link betweeen rows. Therefore I had to find matching data in the rows and manually link them as described in the code. 
I didnt expect to merge what looked like two rows and have six or so tacked on as what I assume were remnants from the SCV...had to break out the columns and remerge them to do so
And holy cow I thought having meta data separate from nodes was going to make my life easier, but it really made it so much worse. It was very difficult knowing the SQL sorts of commands and having instead to figure out how to 
			get R to work with it instead. I started off with many more for loops than i ended up with , but still had to use some to assign true names and species to the ID's after the nodes/edges were entered into the graph. 


If I knew how to better navigate the software, I think it would be interesting to apply more colors to distinguish between breeds rather than just species, or to change the edges to reflect whether the link was dog/dog, cat/cat, or dog/cat,
and how pet owners of different animals sought to connect their pets online


I have included several PDF results of my file with different amounts of data: theoretically it should work fine with the whole set, but I waited over an hour for it to plot all the points and it still wouldnt finish. The maximum data set included is 5000, followed by 2000. NOte this is why the grey circles of unknown species show up so much: the chance of the related pet ID being in the limited file is low, so most do not get changed from their numerical value and assigned metadata. IN addition, I also ran a set with the entirety of the metadata and 2200 of the links, which still took a while but decreased the chance of not being found by over 50%, which is pretty good as I expect many pet owners would delete their accounts rather than change their usernames to a memorial like many others did.


In addition, this project was approved for a slight extension. Thank you!