Lsb5

I am still very much struggling with angular, and am having troubles wrapping my head around node. If there werent so many guides online for dealing with the twitter API and node specifically im not sure what I would have done, especially on the server part. 

Otherwise, contained in this lab:

server that reads tweets, hosts html page, tells user what they have done,
html page that has basic reactive interface to allow the user to submit queries and number of such to the server for output to json
json with output collected so far. 

Im still having trouble figuring out how to grab specific portions of tweets, so the search can grab literally every related value to the tweet, and it doesnt fetch every single bit of information, but every detail isnt important either, so I didn't bother fixing it. 