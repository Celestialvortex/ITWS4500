'use strict';

// Load dependencies
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const server = require('http').createServer(app);
const path = require('path');
const fs = require('fs');
const https = require('https');
const request = require('request');
const consumerKey = 'XcFqGQvlAmCSR6GtdsP7B941A';
const consumerSecret = 'iUibsPEuZI0mtn4I89qOGjmPVP12E18ypIEY58mApEG9EArSKI'; //stuff given by twitter to let you use their stuff
const outputFilename = 'franse-tweets.json'; //as requested by the lab

// Set root folder
app.use(express.static(__dirname)); //use express
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true })); //deal with encoded and non encoded json

app.post('/Tweetgrabber', (req, res) => {
  var query = req.body.query; //pull query from html page
  var numberr = req.body.numberr; //number pulled from html page
  authorizeApp(query, numberr);//authroize with twitter
  if (query != ''){ //if something is in the text box, do the thing
  res.send('You have now saved '+numberr+' tweets in regards to '+query+'!');    //confirm to users}
}

    else{//give error and stop the thing
      res.send('uh oh! you have an error! Please refresh and try again!');
      return;
    }
});

function Tweetgrabber(accessToken, query, numberr) { //function for grabbing tweets
  var tweetSearchOptions = { 
    count: numberr //obeys numbers set 
  };

  if (query) {
    tweetSearchOptions.q = query; //search via the query
  }

  request.get({
    headers: { 'Authorization': 'Bearer ' + accessToken }, // get data using tokens
    url: 'https://api.twitter.com/1.1/search/tweets.json',
    json: true,
    qs: tweetSearchOptions
  }, (e, r, b) => {
    fs.writeFile(outputFilename, JSON.stringify(b.statuses, null, 2), (err) => { //attempt to write the file
      if (err) {
        throw err;
      }


    });
  });
}

  // as instructed by online twitter API guide
function authorizeApp(query, numberr) { // used to authorize probing of twitter. Consent is a good thing! 

  var bearerTokenCredentials = consumerKey + ':' + consumerSecret; //my info
  var encodedCredentials = new Buffer(bearerTokenCredentials).toString('base64');
  var authRquestOptions = { //options in regards to request
    hostname: 'api.twitter.com',
    path: '/oauth2/token',
    method: 'POST',
    headers: {
      'Authorization': 'Basic ' + encodedCredentials,
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    }
  };

  var authRequest = https.request(authRquestOptions, (res) => { //once authorized, get data and encode to where parseable, 
    res.setEncoding('utf8'); 
    res.on('data', (chunk) => {
      var accessToken = JSON.parse(chunk).access_token; //parse of json
      Tweetgrabber(accessToken, query, numberr); // run above function
    });
  });

  var body = 'grant_type=client_credentials';
  authRequest.write(body);
  authRequest.end();
  console.log('all done with request for '+query);
}

server.listen(3000);
